--Easy
--Who is the senior most employee based on job title?
SELECT TOP(1)
	first_name,
	last_name,
	title
FROM employee
ORDER BY levels DESC;

--Which countries have the most invoices?
SELECT billing_country, COUNT(invoice_id) AS Most_invoices
FROM invoice
GROUP BY billing_country
ORDER BY Most_invoices DESC;

--What are top 3 values of total invoice?
SELECT TOP(3) billing_country, total
FROM invoice
ORDER BY total DESC;


/*Which city has the best customer? We would like like to throw a promotional music festival in the city we 
made the most money.Write a query that returns one city that has the highest sum of invoice totals. 
Return both the city name & sum of all invoice totals*/
SELECT billing_city, ROUND(SUM(total),2) AS Total_invoice 
FROM invoice
GROUP BY billing_city
ORDER BY Total_invoice DESC;


/*Who is the best customer? the customer who spent the most money will be declared the best customer. Write a
query that returns the person who has spent the most money.*/
SELECT TOP(1) c.customer_id,c.first_name,c.last_name, ROUND(SUM(inv.total),2) AS money_spent
FROM customer AS c
LEFT JOIN invoice AS inv ON c.customer_id = inv.customer_id
GROUP BY c.first_name,c.last_name,c.customer_id
ORDER BY money_spent DESC;


--Moderate
/*Write a query to return the email, first_name, last_name, & Genre of all rock music listeners. Return your
list ordered alphabetically by email start with A */
SELECT DISTINCT first_name,last_name,email 
FROM customer
INNER JOIN invoice ON customer.customer_id = invoice.customer_id
INNER JOIN invoice_line ON invoice.invoice_id = invoice_line.invoice_id
WHERE track_id IN( SELECT t.track_id FROM track AS t
                   LEFT JOIN genre AS g ON g.genre_id = t.genre_id
                   WHERE g.name = 'Rock') 
ORDER BY email


/*Lets invite the artist who have written the most rock music in our dataset.Write a query thats return 
the artist name and total count of the top 10 rock bands*/
SELECT TOP(10) artist.artist_id,artist.name,COUNT(artist.artist_id) AS number_of_song
FROM track 
LEFT JOIN album ON album.album_id = track.album_id
LEFT JOIN artist ON artist.artist_id = album.artist_id
LEFT JOIN genre ON genre.genre_id = track.genre_id
GROUP BY artist.artist_id,artist.name
ORDER BY number_of_song DESC


/*Return all the track names that have a song that length longer than the average song length.Return the name
and milliseconds for each track.Order by the song length with the longest songs listed first.*/
select name,milliseconds 
from track
WHERE milliseconds > (SELECT AVG(milliseconds) FROM track)
order by milliseconds DESC


--Advance
/*Find how much amount spent by each customer on artist? Write a query to return customer name, artist name
and total spent*/
WITH best_artist AS (
SELECT TOP (1) a.artist_id, a.name AS artist_name, SUM(il.unit_price * il.quantity) AS total_sales
FROM invoice_line AS il
JOIN track AS t ON il.track_id = t.track_id
JOIN album AS am ON t.album_id = am.album_id
JOIN artist AS a ON am.album_id = a.artist_id
GROUP BY a.artist_id,a.name
ORDER BY total_sales DESC
)

SELECT c.first_name, c.last_name, bs.artist_name, SUM(il.unit_price * il.quantity) AS total_sales
FROM invoice AS i
JOIN customer AS c ON c.customer_id = i.customer_id
JOIN invoice_line AS il ON il.invoice_id = i.invoice_id
JOIN track AS t ON t.track_id = il.track_id
JOIN album AS al ON al.album_id = t.album_id
JOIN best_artist AS bs ON bs.artist_id = al.artist_id
GROUP BY  c.first_name, c.last_name, bs.artist_name
ORDER BY total_sales DESC


/*We want to find out the most popular music genre for each country.We determine the most popular genre as 
the genre with the highest amount of purchase.Write a query that returns each country along with the top Genre.
For countries were the maximum number of purchase is shared return all genres.*/
WITH popular_genere AS(
SELECT DISTINCT g.name, g.genre_id, c.country, COUNT(il.quantity) AS maximum_purchase,
ROW_NUMBER() OVER(PARTITION BY c.country ORDER BY COUNT(il.quantity) DESC) AS Row_No 
FROM invoice_line AS il
JOIN invoice AS i ON i.invoice_id = il.invoice_id
JOIN customer AS c ON c.customer_id = i.customer_id
JOIN track AS t ON t.track_id = il.track_id
JOIN genre AS g ON g.genre_id = t.genre_id
GROUP BY g.name,c.country,g.genre_id
--ORDER BY c.country ASC
)
SELECT * FROM popular_genere
WHERE Row_No <=1

/*Write a query that detemines the customer that has spent the most on music for each country.Write a query that
returns the country along with the top customer and how much money they spent.For countries where the top amount
spent is shared,provide all customer who spent this amount*/
WITH 
	customer_with_country AS (
		SELECT c.customer_id, c.first_name, c.last_name,i.billing_country,SUM(total) AS total_spend
		FROM invoice AS i
		JOIN customer AS c ON c.customer_id = i.customer_id
		GROUP BY c.customer_id, c.first_name, c.last_name,i.billing_country
		),

	country_max_spending AS (
		SELECT cwc.billing_country, MAX(total_spend) AS max_spending
		FROM customer_with_country AS cwc
		GROUP BY cwc.billing_country)
SELECT cwc.billing_country, cwc.total_spend, cwc.first_name, cwc.last_name,cwc.customer_id
FROM customer_with_country AS cwc
JOIN country_max_spending AS cws ON cwc.billing_country = cws.billing_country
WHERE cwc.total_spend = cws.max_spending
ORDER BY cwc.billing_country